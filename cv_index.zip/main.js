document.body.innerHTML = "This is some content";
